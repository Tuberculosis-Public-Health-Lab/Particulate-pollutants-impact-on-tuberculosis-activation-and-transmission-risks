##########-------- Air pollutants and tuberculosis risk --------##########

# Clear the current working environment
rm(list=ls())  

# Set the working directory
setwd("C:/Users/bltao/") 

# Load tuberculosis case data
cases_df <- data.frame(readxl::read_xlsx("C:/Users/bltao/Jiangsu_Tuberculosis_Data.xlsx"))

# Load air pollutant and meteorological data
pollutants_df <- data.frame(readxl::read_xlsx("C:/Users/bltao/Jiangsu_AirPolutants_Data.xlsx"))

# Load necessary libraries
library(dplyr)  
library(lubridate)  
library(mgcv)  # For Generalized Additive Models

# Convert dates to Date type (if not already converted)
cases_df$date <- as.Date(cases_df$date)  
pollutants_df$date <- as.Date(pollutants_df$date)  

# Summarize monthly cases
monthly_cases <- cases_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    total_cases = n(),  
    .groups = "drop"  
  )  

# Summarize monthly air pollutant data (PM10)
monthly_PM10 <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    PM10_mean = mean(PM10, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly air pollutant data (PM2.5)
monthly_PM2.5 <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    PM2.5_mean = mean(PM2.5, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly air pollutant data (SO2)
monthly_SO2 <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    SO2_mean = mean(SO2, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly air pollutant data (NO2)
monthly_NO2 <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    NO2_mean = mean(NO2, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly air pollutant data (O3)
monthly_O3 <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    O3_mean = mean(O3, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly air pollutant data (CO)
monthly_CO <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    CO_mean = mean(CO, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly average temperature
monthly_temperature <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    temperature_mean = mean(avg_temp, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly average pressure
monthly_pressure <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%   
  summarise(  
    pressure_mean = mean(avg_pressure, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly average humidity
monthly_humidity <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    humidity_mean = mean(avg_humidity, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly average wind speed
monthly_wind <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%     
  summarise(  
    wind_mean = mean(avg_windspeed, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Summarize monthly average sunshine duration
monthly_sunshine <- pollutants_df %>%  
  mutate(month_start = floor_date(date, unit = "month")) %>%  
  group_by(region, month_start) %>%  
  summarise(  
    sunshine_mean = mean(avg_sunshine, na.rm = TRUE), 
    .groups = "drop"  
  )  

# Merge pollutant data
monthly_pollutants <- cbind(monthly_PM10, monthly_PM2.5[,3], monthly_SO2[,3], monthly_NO2[,3], monthly_O3[,3], monthly_CO[,3],
                            monthly_temperature[,3], monthly_pressure[,3], monthly_humidity[,3], monthly_wind[,3], monthly_sunshine[,3])

# Initialize an empty list to store 13 datasets (including the original)
data_cases_lag <- list()

# Loop through 0 to 12 months (lag periods)
for (i in 0:12) {
  new_df <- monthly_cases
  if (i > 0) {
    new_df$month_start <- new_df$month_start %m-% months(i)
  }
  data_cases_lag[[i + 1]] <- new_df
}

# Merge list elements
combined_df <- list()  
for (i in 1:13) {
  combined_df[[i]] <- left_join(data_cases_lag[[i]], monthly_pollutants, by = c("month_start", "region"))
} 

# Extract months
for(i in 1:13){
  combined_df[[i]] <- combined_df[[i]] %>%
    mutate(Month = as.numeric(format(month_start, "%m")))
}











#### ---- GAM for PM10 ---- ####
# Load necessary libraries
library(dplyr)
library(mgcv)
# Set the number of decimal places for output results
digit <- 4 

# Initialize variables to store results
mod <- list()
coef <- NULL
OR <- NULL
LowCI <- NULL
UpperCI <- NULL
changeOR <- NULL
changeLow <- NULL
changeUpper <- NULL
se <- NULL
t.value <- NULL
Pvalue <- NULL

# Initialize result matrix and set column names
result <- matrix(NA, nrow=13, ncol=10)
colnames(result) <- c("coef", "OR", "LowCI", "UpperCI", "changeOR", "changeLow", "changeUpper", "se", "t.value", "Pvalue")

# Loop to build models and extract results

for(i in 1:13){
  mod[[i]] <- gam(total_cases ~ 
                    PM10_mean +
                    as.factor(region) +
                    s(Month, bs = 'cc') + 
                    s(temperature_mean) + 
                    s(humidity_mean) +
                    s(wind_mean) + 
                    s(sunshine_mean), 
                  
                  data = combined_df[[i]],   
                  family = quasipoisson(link = "log"), 
                  method = "GCV.Cp",
                  na.action = "na.omit") # Omit missing values
  
  # Extract coefficient, standard error, t-value, and p-value
  a <- summary(mod[[i]])$p.coeff[2]
  b <- summary(mod[[i]])$se[2]
  t <- round(summary(mod[[i]])$p.t[2], 3)
  e <- round(summary(mod[[i]])$p.pv[2], 5)
  
  # Calculate and extract odds ratio (OR) and its confidence interval
  c <- round(exp(10*coef(mod[[i]]))[2], digit)
  d <- as.data.frame(round(exp(10*confint.default(mod[[i]])), digit))
  Low <- d[2, 1]
  Upper <- d[2, 2]
  
  # Calculate percentage change in odds ratio
  f <- round((c - 1) * 100, digit)
  g <- round((Low - 1) * 100, digit)
  h <- round((Upper - 1) * 100, digit)
  
  # Fill the result matrix
  result[i,] <- c(a, c, Low, Upper, f, g, h, b, t, e)
}

# set Lag months
Lag <- seq(0, 12, by = 1)

# merging data
PM10_result <- cbind(Lag,result)

# convert data to a data frame
PM10_data <- as.data.frame(PM10_result)

# View PM2.5_data
View(PM10_data)







#### ---- Plotting Residuals for PM10---- #### 
# Load necessary libraries for plotting

library(ggplot2)
library(RColorBrewer)
library(readxl)

# Optionally check the structure of the PM10_data
str(PM10_data)

# Assuming the PM10_dataframe contains columns: Lag, changeLow, changeUpper, changeOR, Pvalue
# Modify column names if necessary
# Set color palette

color_palette <- brewer.pal(4, "Dark2")
mycolor <- colorRampPalette(color_palette)(length(unique(PM10_data$Lag)))  # Set number of colors based on unique Lag values

# Convert Lag to factor and set labels if needed
PM10_data$Lag <- as.factor(PM10_data$Lag)

# Add significance labels based on P-values
PM10_data$Significance <- ifelse(PM10_data$Pvalue < 0.001, "***",
                            ifelse(PM10_data$Pvalue < 0.01, "**",
                                   ifelse(PM10_data$Pvalue < 0.05, "*", "")))


p1 <- ggplot(PM10_data, aes(x = Lag, ymin = changeLow, ymax = changeUpper, y = changeOR, color = Lag)) +
  geom_errorbar(width = 0.2, size = 1, position = position_dodge(width = 2)) +
  geom_point(size = 5, position = position_dodge(width = 1)) +
  
  # Add significance labels
  geom_text(aes(label = Significance, y = changeUpper + 0.05 * (changeUpper - changeLow)),
            vjust = -0.1, size = 6, color = "black") +
  
  scale_color_manual(values = mycolor) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 16),
    axis.title.x = element_text(size = 16),
    axis.text.y = element_text(size = 16),
    axis.title.y = element_text(size = 16),
    # Remove legend
    legend.position = "none",
    # Add border if needed
    panel.border = element_rect(colour = "black", fill = NA, size = 1),
    # Center title
    plot.title = element_text(hjust = 0.5, size = 20)
  ) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  # Add title with PM10 subscript
  labs(
    title = expression(paste("PM"[10], ": Changes in PTB risk by varying lag period")),
    x = "Lag (months)",
    y = expression(paste("Changes in PTB risk and 95% CI (%)"))
  ) +
  # Add note on significance levels at the top left
  annotate("text", x = -Inf, y = Inf, label = "significant levels: * p <0.05, ** p <0.01, *** p <0.001",
           hjust = -0.05, vjust = 2, size = 5, color = "black")

# Display the plot
print(p1)









#### ---- GAM for PM2.5 ---- ####
# Load necessary libraries
library(dplyr)
library(mgcv)
# Set the number of decimal places for output results
digit <- 4 

# Initialize variables to store results
mod <- list()
coef <- NULL
OR <- NULL
LowCI <- NULL
UpperCI <- NULL
changeOR <- NULL
changeLow <- NULL
changeUpper <- NULL
se <- NULL
t.value <- NULL
Pvalue <- NULL

# Initialize result matrix and set column names
result <- matrix(NA, nrow=13, ncol=10)
colnames(result) <- c("coef", "OR", "LowCI", "UpperCI", "changeOR", "changeLow", "changeUpper", "se", "t.value", "Pvalue")

# Loop to build models and extract results

for(i in 1:13){
  mod[[i]] <- gam(total_cases ~ 
                    PM2.5_mean +
                    as.factor(region) +
                    s(Month, bs = 'cc') + 
                    s(temperature_mean) + 
                    s(humidity_mean) +
                    s(wind_mean) + 
                    s(sunshine_mean), 
                  
                  data = combined_df[[i]],   
                  family = quasipoisson(link = "log"), 
                  method = "GCV.Cp",
                  na.action = "na.omit") # Omit missing values
  
  # Extract coefficient, standard error, t-value, and p-value
  a <- summary(mod[[i]])$p.coeff[2]
  b <- summary(mod[[i]])$se[2]
  t <- round(summary(mod[[i]])$p.t[2], 3)
  e <- round(summary(mod[[i]])$p.pv[2], 5)
  
  # Calculate and extract odds ratio (OR) and its confidence interval
  c <- round(exp(10*coef(mod[[i]]))[2], digit)
  d <- as.data.frame(round(exp(10*confint.default(mod[[i]])), digit))
  Low <- d[2, 1]
  Upper <- d[2, 2]
  
  # Calculate percentage change in odds ratio
  f <- round((c - 1) * 100, digit)
  g <- round((Low - 1) * 100, digit)
  h <- round((Upper - 1) * 100, digit)
  
  # Fill the result matrix
  result[i,] <- c(a, c, Low, Upper, f, g, h, b, t, e)
}

# set Lag months
Lag <- seq(0, 12, by = 1)

# merging data
PM2.5_result <- cbind(Lag,result)

# convert data to a data frame
PM2.5_data <- as.data.frame(PM2.5_result)

# View PM2.5_data
View(PM2.5_data)









#### ---- Plotting Residuals for PM2.5 ---- #### 
# Load necessary libraries for plotting

library(ggplot2)
library(RColorBrewer)
library(readxl)

# Optionally check the structure of the PM2.5_data
str(PM2.5_data)

# Assuming the PM2.5_dataframe contains columns: Lag, changeLow, changeUpper, changeOR, Pvalue
# Modify column names if necessary
# Set color palette

color_palette <- brewer.pal(4, "Dark2")
mycolor <- colorRampPalette(color_palette)(length(unique(PM2.5_data$Lag)))  # Set number of colors based on unique Lag values

# Convert Lag to factor and set labels if needed
PM2.5_data$Lag <- as.factor(PM2.5_data$Lag)

# Add significance labels based on P-values
PM2.5_data$Significance <- ifelse(PM2.5_data$Pvalue < 0.001, "***",
                            ifelse(PM2.5_data$Pvalue < 0.01, "**",
                                   ifelse(PM2.5_data$Pvalue < 0.05, "*", "")))


p2 <- ggplot(PM2.5_data, aes(x = Lag, ymin = changeLow, ymax = changeUpper, y = changeOR, color = Lag)) +
  geom_errorbar(width = 0.2, size = 1, position = position_dodge(width = 2)) +
  geom_point(size = 5, position = position_dodge(width = 1)) +
  
  # Add significance labels
  geom_text(aes(label = Significance, y = changeUpper + 0.05 * (changeUpper - changeLow)),
            vjust = -0.1, size = 6, color = "black") +
  
  scale_color_manual(values = mycolor) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 16),
    axis.title.x = element_text(size = 16),
    axis.text.y = element_text(size = 16),
    axis.title.y = element_text(size = 16),
    # Remove legend
    legend.position = "none",
    # Add border if needed
    panel.border = element_rect(colour = "black", fill = NA, size = 1),
    # Center title
    plot.title = element_text(hjust = 0.5, size = 20)
  ) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  # Add title with PM10 subscript
  labs(
    title = expression(paste("PM"[2.5], ": Changes in PTB risk by varying lag period")),
    x = "Lag (months)",
    y = expression(paste("Changes in PTB risk and 95% CI (%)"))
  ) +
  # Add note on significance levels at the top left
  annotate("text", x = -Inf, y = Inf, label = "significant levels: * p <0.05, ** p <0.01, *** p <0.001",
           hjust = -0.05, vjust = 2, size = 5, color = "black")

# Display the plot
print(p2)


# arrange plot
library(gridExtra)
grid.arrange(p1,p2,ncol=2)





