##########-------- Ambient Air Particle Pollutants and Endogenous Activation of BEAST Molecular Clock --------#########

# Clear all existing objects
rm(list=ls()) 

# Set working directory
setwd("C:/Users/bltao/Graduation Thesis Data and Code") 

# Load the dataset for endogenous activation
df <- data.frame(readxl::read_xlsx("EndogenousActivation_Data.xlsx"))

# Filter samples with endogenous activation of Mycobacterium tuberculosis within the last 3 years
df <- dplyr::filter(df, Time.Branch.Length.30SNPs <= 3)

# Load daily environmental and meteorological data for Donghai from 2014-2020
dfA <- data.frame(readxl::read_xlsx("Donghai_AirPollutants_Data.xlsx"))
library(zoo)
# Exposure window size of 1-12 months
DateDigit <- NULL
RowID <- NULL
datalagA <- list()

for (i in 1:12) {
  datalagA[[i]] <- rollmean(dfA[,-c(1,2)], i*30)
  
  DateDigit <- seq(41640+i*30-1, length.out=nrow(datalagA[[i]]), by=1)
  RowID <- seq(i*30, length.out=nrow(datalagA[[i]]), by=1)
  ID <- paste0(rep("Donghai", nrow(datalagA[[i]])), DateDigit)
  
  datalagA[[i]] <- cbind(RowID, DateDigit, ID, datalagA[[i]])
}

View(datalagA[[1]])

# Calculate the rolling average of air pollutants and meteorological variables within a sliding window (30-day window)
# Load daily environmental and meteorological data for Guannan from 2014-2020
dfB <- data.frame(readxl::read_xlsx("Guannan_AirPollutants_Data.xlsx"))
library(zoo)
# Exposure window size of 1-12 months
DateDigit <- NULL
RowID <- NULL
datalagB <- list()

for (i in 1:12) {
  datalagB[[i]] <- rollmean(dfB[,-c(1,2)], i*30)
  
  DateDigit <- seq(41640+i*30-1, length.out=nrow(datalagB[[i]]), by=1)
  RowID <- seq(i*30, length.out=nrow(datalagB[[i]]), by=1)
  ID <- paste0(rep("Guannan", nrow(datalagB[[i]])), DateDigit)
  
  datalagB[[i]] <- cbind(RowID, DateDigit, ID, datalagB[[i]])
}

View(datalagB[[1]])

# Load daily environmental and meteorological data for Guanyun from 2014-2020
dfC <- data.frame(readxl::read_xlsx("Guanyun_AirPollutants_Data.xlsx"))
library(zoo)
# Exposure window size of 1-12 months
DateDigit <- NULL
RowID <- NULL
datalagC <- list()

for (i in 1:12) {
  datalagC[[i]] <- rollmean(dfC[,-c(1,2)], i*30)
  
  DateDigit <- seq(41640+i*30-1, length.out=nrow(datalagC[[i]]), by=1)
  RowID <- seq(i*30, length.out=nrow(datalagC[[i]]), by=1)
  ID <- paste0(rep("Guanyun", nrow(datalagC[[i]])), DateDigit)
  
  datalagC[[i]] <- cbind(RowID, DateDigit, ID, datalagC[[i]])
}

View(datalagC[[1]])

# Load daily environmental and meteorological data for Haizhou from 2014-2020
dfD <- data.frame(readxl::read_xlsx("Haizhou_AirPollutants_Data.xlsx"))
library(zoo)
# Exposure window size of 1-12 months
DateDigit <- NULL
RowID <- NULL
datalagD <- list()

for (i in 1:12) {
  datalagD[[i]] <- rollmean(dfD[,-c(1,2)], i*30)
  
  DateDigit <- seq(41640+i*30-1, length.out=nrow(datalagD[[i]]), by=1)
  RowID <- seq(i*30, length.out=nrow(datalagD[[i]]), by=1)
  ID <- paste0(rep("Haizhou", nrow(datalagD[[i]])), DateDigit)
  
  datalagD[[i]] <- cbind(RowID, DateDigit, ID, datalagD[[i]])
}

View(datalagD[[1]])

# Load daily environmental and meteorological data for Ganyu from 2014-2020
dfE <- data.frame(readxl::read_xlsx("Ganyu_AirPollutants_Data.xlsx"))
library(zoo)
# Exposure window size of 1-12 months
DateDigit <- NULL
RowID <- NULL
datalagE <- list()

for (i in 1:12) {
  datalagE[[i]] <- rollmean(dfE[,-c(1,2)], i*30)
  
  DateDigit <- seq(41640+i*30-1, length.out=nrow(datalagE[[i]]), by=1)
  RowID <- seq(i*30, length.out=nrow(datalagE[[i]]), by=1)
  ID <- paste0(rep("Ganyu", nrow(datalagE[[i]])), DateDigit)
  
  datalagE[[i]] <- cbind(RowID, DateDigit, ID, datalagE[[i]])
}

View(datalagE[[1]])

# Load daily environmental and meteorological data for Lianyun from 2014-2020
dfF <- data.frame(readxl::read_xlsx("Lianyun_AirPollutants_Data.xlsx"))
library(zoo)
# Exposure window size of 1-12 months
DateDigit <- NULL
RowID <- NULL
datalagF <- list()

for (i in 1:12) {
  datalagF[[i]] <- rollmean(dfF[,-c(1,2)], i*30)
  
  DateDigit <- seq(41640+i*30-1, length.out=nrow(datalagF[[i]]), by=1)
  RowID <- seq(i*30, length.out=nrow(datalagF[[i]]), by=1)
  ID <- paste0(rep("Lianyun", nrow(datalagF[[i]])), DateDigit)
  
  datalagF[[i]] <- cbind(RowID, DateDigit, ID, datalagF[[i]])
}

View(datalagF[[1]])

# Combine datasets vertically
datalag <- list()
for (i in 1:12) {
  datalag[[i]] <- rbind(datalagA[[i]], datalagB[[i]], datalagC[[i]], datalagD[[i]], datalagE[[i]], datalagF[[i]])
}

View(datalag[[1]])

# Remove intermediate datasets
rm(dfA); rm(dfB); rm(dfC); rm(dfD); rm(dfE); rm(dfF); rm(datalagA); rm(datalagB); rm(datalagC); rm(datalagD); rm(datalagE); rm(datalagF)

# Rename variable
library(gdata)
df <- rename.vars(df, from = "Place_Time", to = "ID", info=TRUE)

# Combine datasets horizontally (merge pollutant data with strain dataset)
datalagok <- list()
for (i in 1:12) {
  datalagok[[i]] <- merge(datalag[[i]], df, by="ID")
}

# Convert environmental variables from character to numeric
options(digits = 3)
for (i in 1:12) {
  datalagok[[i]][,4:14] <- lapply(datalagok[[i]][,4:14], as.numeric)
}








#### ---- GAM for PM10 ---- ####
# Load necessary libraries
library(dplyr)
library(mgcv)
# Set the number of decimal places for output results
digit <- 4 

# Initialize variables to store results
mod <- list()
coef <- NULL
OR <- NULL
LowCI <- NULL
UpperCI <- NULL
changeOR <- NULL
changeLow <- NULL
changeUpper <- NULL
se <- NULL
t.value <- NULL
Pvalue <- NULL

# Initialize result matrix and set column names
result <- matrix(NA, nrow=12, ncol=10)
colnames(result) <- c("coef", "OR", "LowCI", "UpperCI", "changeOR", "changeLow", "changeUpper", "se", "t.value", "Pvalue")

# Loop to build models and extract results

for(i in 1:12){
  mod[[i]] <- gam(log(Substi.Branch.Length.30SNPs) ~  PM10 +
                    
                    as.factor(Place_name)+
                    as.factor(age_group)+
                    as.factor(occupation)+
                    as.factor(sex)+
                    as.factor(Diabetes)+
                    as.factor(treat_history)+
                    as.factor(main_lineage)+
                    as.factor(DR_type)+
                    
                    s(Month, bs = 'cc') + 
                    s(avg_temp,bs='tp')+
                    s(avg_humidity,bs='tp')+
                    s(avg_windspeed,bs='tp')+
                    s(avg_sunshine,bs='tp'),
                  
                  family = gaussian(link = "identity"),
                  offset = Time.Branch.Length.30SNPs,
                  na.action = "na.omit", # Omit missing values
                  data=datalagok[[i]]) 
  
  # Extract coefficient, standard error, t-value, and p-value
  a <- summary(mod[[i]])$p.coeff[2]
  b <- summary(mod[[i]])$se[2]
  t <- round(summary(mod[[i]])$p.t[2], 3)
  e <- round(summary(mod[[i]])$p.pv[2], 5)
  
  # Calculate and extract odds ratio (OR) and its confidence interval
  c <- round(exp(10*coef(mod[[i]]))[2], digit)
  d <- as.data.frame(round(exp(10*confint.default(mod[[i]])), digit))
  Low <- d[2, 1]
  Upper <- d[2, 2]
  
  # Calculate percentage change in odds ratio
  f <- round((c - 1) * 100, digit)
  g <- round((Low - 1) * 100, digit)
  h <- round((Upper - 1) * 100, digit)
  
  # Fill the result matrix
  result[i,] <- c(a, c, Low, Upper, f, g, h, b, t, e)
}

# set Exposure Windows Size (unit: month)
Exposure_Window_Size <- seq(1, 12, by = 1)

# merging data
PM10_result <- cbind(Exposure_Window_Size,result)

# convert data to a data frame
PM10_data <- as.data.frame(PM10_result)

# View PM10_data
View(PM10_data)









#### ---- Plotting Residuals for PM10---- #### 
# Load necessary libraries for plotting

library(ggplot2)
library(RColorBrewer)
library(readxl)

# Optionally check the structure of the PM10_data
str(PM10_data)

# Assuming the PM10_dataframe contains columns: Exposure_Window_Size, changeLow, changeUpper, changeOR, Pvalue
# Modify column names if necessary
# Set color palette

color_palette <- brewer.pal(4, "Dark2")
mycolor <- colorRampPalette(color_palette)(length(unique(PM10_data$Exposure_Window_Size)))  # Set number of colors based on unique Exposure_Window_Size values

# Convert Exposure_Window_Size to factor and set labels if needed
PM10_data$Exposure_Window_Size <- as.factor(PM10_data$Exposure_Window_Size)

# Add significance labels based on P-values
PM10_data$Significance <- ifelse(PM10_data$Pvalue < 0.001, "***",
                                 ifelse(PM10_data$Pvalue < 0.01, "**",
                                        ifelse(PM10_data$Pvalue < 0.05, "*", "")))


p1 <- ggplot(PM10_data, aes(x = Exposure_Window_Size, ymin = changeLow, ymax = changeUpper, y = changeOR, color = Exposure_Window_Size)) +
  geom_errorbar(width = 0.2, size = 1, position = position_dodge(width = 2)) +
  geom_point(size = 5, position = position_dodge(width = 1)) +
  
  # Add significance labels
  geom_text(aes(label = Significance, y = changeUpper + 0.05 * (changeUpper - changeLow)),
            vjust = -0.1, size = 6, color = "black") +
  
  scale_color_manual(values = mycolor) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 16),
    axis.title.x = element_text(size = 16),
    axis.text.y = element_text(size = 16),
    axis.title.y = element_text(size = 16),
    # Remove legend
    legend.position = "none",
    # Add border if needed
    panel.border = element_rect(colour = "black", fill = NA, size = 1),
    # Center title
    plot.title = element_text(hjust = 0.5, size = 20)
  ) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  # Add title with PM10 subscript
  labs(
    title = expression(paste("PM"[10], " ")),
    x = "Exposure window size (months)",
    y = expression(paste("Changes in MTB phylogenetic molecular clock during endogenous activation and 95% CI (%)"))
  ) +
  # Add note on significance levels at the top left
  annotate("text", x = -Inf, y = Inf, label = "significant levels: * p <0.05, ** p <0.01, *** p <0.001",
           hjust = -0.05, vjust = 2, size = 5, color = "black")

# Display the plot
print(p1)









#### ---- GAM for PM2.5 ---- ####
# Load necessary libraries
library(dplyr)
library(mgcv)
# Set the number of decimal places for output results
digit <- 4 

# Initialize variables to store results
mod <- list()
coef <- NULL
OR <- NULL
LowCI <- NULL
UpperCI <- NULL
changeOR <- NULL
changeLow <- NULL
changeUpper <- NULL
se <- NULL
t.value <- NULL
Pvalue <- NULL

# Initialize result matrix and set column names
result <- matrix(NA, nrow=12, ncol=10)
colnames(result) <- c("coef", "OR", "LowCI", "UpperCI", "changeOR", "changeLow", "changeUpper", "se", "t.value", "Pvalue")

# Loop to build models and extract results

for(i in 1:12){
  mod[[i]] <- gam(log(Substi.Branch.Length.30SNPs) ~  PM2.5 +
                    
                    as.factor(Place_name)+
                    as.factor(age_group)+
                    as.factor(occupation)+
                    as.factor(sex)+
                    as.factor(Diabetes)+
                    as.factor(treat_history)+
                    as.factor(main_lineage)+
                    as.factor(DR_type)+
                    
                    s(Month, bs = 'cc') + 
                    s(avg_temp,bs='tp')+
                    s(avg_humidity,bs='tp')+
                    s(avg_windspeed,bs='tp')+
                    s(avg_sunshine,bs='tp'),
                  
                  family = gaussian(link = "identity"),
                  offset = Time.Branch.Length.30SNPs,
                  na.action = "na.omit", # Omit missing values
                  data=datalagok[[i]]) 
  
  # Extract coefficient, standard error, t-value, and p-value
  a <- summary(mod[[i]])$p.coeff[2]
  b <- summary(mod[[i]])$se[2]
  t <- round(summary(mod[[i]])$p.t[2], 3)
  e <- round(summary(mod[[i]])$p.pv[2], 5)
  
  # Calculate and extract odds ratio (OR) and its confidence interval
  c <- round(exp(10*coef(mod[[i]]))[2], digit)
  d <- as.data.frame(round(exp(10*confint.default(mod[[i]])), digit))
  Low <- d[2, 1]
  Upper <- d[2, 2]
  
  # Calculate percentage change in odds ratio
  f <- round((c - 1) * 100, digit)
  g <- round((Low - 1) * 100, digit)
  h <- round((Upper - 1) * 100, digit)
  
  # Fill the result matrix
  result[i,] <- c(a, c, Low, Upper, f, g, h, b, t, e)
}

# set Exposure Windows Size (unit: month)
Exposure_Window_Size <- seq(1, 12, by = 1)

# merging data
PM2.5_result <- cbind(Exposure_Window_Size,result)

# convert data to a data frame
PM2.5_data <- as.data.frame(PM2.5_result)

# View PM10_data
View(PM2.5_data)









#### ---- Plotting Residuals for PM2.5---- #### 
# Load necessary libraries for plotting

library(ggplot2)
library(RColorBrewer)
library(readxl)

# Optionally check the structure of the PM2.5_data
str(PM2.5_data)

# Assuming the PM2.5_dataframe contains columns: Exposure_Window_Size, changeLow, changeUpper, changeOR, Pvalue
# Modify column names if necessary
# Set color palette

color_palette <- brewer.pal(4, "Dark2")
mycolor <- colorRampPalette(color_palette)(length(unique(PM2.5_data$Exposure_Window_Size)))  # Set number of colors based on unique Exposure_Window_Size values

# Convert Exposure_Window_Size to factor and set labels if needed
PM2.5_data$Exposure_Window_Size <- as.factor(PM2.5_data$Exposure_Window_Size)

# Add significance labels based on P-values
PM2.5_data$Significance <- ifelse(PM2.5_data$Pvalue < 0.001, "***",
                                 ifelse(PM2.5_data$Pvalue < 0.01, "**",
                                        ifelse(PM2.5_data$Pvalue < 0.05, "*", "")))


p2 <- ggplot(PM2.5_data, aes(x = Exposure_Window_Size, ymin = changeLow, ymax = changeUpper, y = changeOR, color = Exposure_Window_Size)) +
  geom_errorbar(width = 0.2, size = 1, position = position_dodge(width = 2)) +
  geom_point(size = 5, position = position_dodge(width = 1)) +
  
  # Add significance labels
  geom_text(aes(label = Significance, y = changeUpper + 0.05 * (changeUpper - changeLow)),
            vjust = -0.1, size = 6, color = "black") +
  
  scale_color_manual(values = mycolor) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 16),
    axis.title.x = element_text(size = 16),
    axis.text.y = element_text(size = 16),
    axis.title.y = element_text(size = 16),
    # Remove legend
    legend.position = "none",
    # Add border if needed
    panel.border = element_rect(colour = "black", fill = NA, size = 1),
    # Center title
    plot.title = element_text(hjust = 0.5, size = 20)
  ) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  # Add title with PM2.5 subscript
  labs(
    title = expression(paste("PM"[2.5], " ")),
    x = "Exposure window size (months)",
    y = expression(paste("Changes in MTB phylogenetic molecular clock during endogenous activation and 95% CI (%)"))
  ) +
  # Add note on significance levels at the top left
  annotate("text", x = -Inf, y = Inf, label = "significant levels: * p <0.05, ** p <0.01, *** p <0.001",
           hjust = -0.05, vjust = 2, size = 5, color = "black")

# Display the plot
print(p2)
