########################----- Ambient Particle Pollutants and Exogenous Transmission of Mycobacterium tuberculosis ----########################
# Clear the current workspace
rm(list = ls())
setwd("C:/Users/bltao/")

########---- Load the index cases data (The number of index cases during the exposure window for the transmission of secondary tuberculosis) ----########

index_transmisison_cases_df <- data.frame(readxl::read_xlsx("Lianyungang_Tuberculosis_Data.xlsx"))

# Convert the date column to Date type if not already
index_transmisison_cases_df$date <- as.Date(index_transmisison_cases_df$date)

# Extract month and day of the week from the date
index_transmisison_cases_df$month <- as.numeric(format(index_transmisison_cases_df$date, "%m"))  # Month (1-12)
index_transmisison_cases_df$day_of_week <- as.factor(format(index_transmisison_cases_df$date, "%u"))  # Day of the week (1-7, 1=Monday)

# load required packages
library(dplyr)
library(lubridate)
library(tidyr)
library(slider)
library(zoo)

# Create a continuous date sequence from the minimum to the maximum date in the dataset
min_date <- min(index_transmisison_cases_df$date)
max_date <- max(index_transmisison_cases_df$date)
date_sequence <- seq(min_date, max_date, by = "day")

# Create a data frame containing all dates and regions
all_dates <- expand_grid(date = date_sequence, region = unique(index_transmisison_cases_df$region))

# Merge the original data with the continuous date data frame, filling missing dates with 0 cases
index_transmisison_cases_df_complete <- left_join(all_dates, index_transmisison_cases_df, by = c("date", "region")) %>%
  replace_na(list(cases = 0))

# Define a range of window sizes (1-52 week)
window_sizes <- seq(7, 364, by = 7)

# Initialize an empty list to store result datasets
index_cases_list <- list()
# Use lapply to iterate over window sizes and calculate rolling sums
index_cases_list <- lapply(window_sizes, function(window_size) {
  index_transmisison_cases_df_complete %>%
    group_by(region) %>%
    arrange(date) %>%
    mutate(index_rolling_cases = rollapplyr(index_cases, width = window_size, FUN = sum, by = 1, fill = NA, na.rm = TRUE)) %>%
    ungroup()  # Ungroup for further processing
})






########---- Load the transmission cases data (The number of the transmission of secondary tuberculosis during the exposure window) ----########

transmisison_cases_df <- data.frame(readxl::read_xlsx("InfectionTimePoint.xlsx"))

# Filter out rows with "NA" in SamplingTimePoint
transmisison_cases_df <- subset(transmisison_cases_df, SamplingTimePoint != "NA")

# Extract month and day of the week from the date
transmisison_cases_df$month <- as.numeric(format(transmisison_cases_df$date, "%m"))  # Month (1-12)
transmisison_cases_df$day_of_week <- as.factor(format(transmisison_cases_df$date, "%u"))  # Day of the week (1-7, 1=Monday)

# Load the pollutants data
pollutants_df <- data.frame(readxl::read_xlsx("连云港全市2014-2020逐日环境气象汇总.xlsx"))
# Convert the date column to Date type if not already
pollutants_df$date <- as.Date(pollutants_df$date)

# Create a continuous date sequence for cases data
min_date <- min(transmisison_cases_df$date)
max_date <- max(transmisison_cases_df$date)
date_sequence <- seq(min_date, max_date, by = "day")

# Create a data frame containing all dates and regions for cases
all_dates <- expand_grid(date = date_sequence, region = unique(transmisison_cases_df$region))

# Merge the original cases data with the continuous date data frame, filling missing dates with 0 cases
transmisison_cases_df_complete <- left_join(all_dates, transmisison_cases_df, by = c("date", "region")) %>%
  replace_na(list(cases = 0))

# Initialize an empty list to store result datasets for cases
data_cases_list <- list()
# Use lapply to iterate over window sizes and calculate rolling sums for cases
data_cases_list <- lapply(window_sizes, function(window_size) {
  transmisison_cases_df_complete %>%
    group_by(region) %>%
    arrange(date) %>%
    mutate(transmission_rolling_cases = rollapplyr(cases, width = window_size, FUN = sum, by = 1, fill = NA, na.rm = TRUE)) %>%
    ungroup()  # Ungroup for further processing
  })


# Process data_cases_list to add additional variables (Month, Urbanization_Level)
for (i in 1:length(data_cases_list)) {
  data_cases_list[[i]] <- data_cases_list[[i]] %>%
    mutate(Month = as.numeric(format(date, "%m")),  # Month (1-12)
           Day_of_week = as.factor(format(date, "%u")),  # Day of the week (1-7, 1=Monday)
           Year = as.factor(format(date, "%Y")),  # Year
           Season = as.factor(case_when(
             month(date) %in% c(3, 4, 5) ~ "1.Spring",
             month(date) %in% c(6, 7, 8) ~ "2.Summer",
             month(date) %in% c(9, 10, 11) ~ "3.Fall",
             TRUE ~ "4.Winter")),
           Urbanization_Level = if_else(region == "Donghai", 45.406,
                                        if_else(region == "Guanyun", 44.796,
                                                if_else(region == "Guannan", 46.675,
                                                        if_else(region == "Haizhou", 86.189,
                                                                if_else(region == "Lianyun", 89.736,
                                                                        if_else(region == "Ganyu", 50.779, NA)))))))
  }


# Process data_cases_list to add population data
population_data <- data.frame(
  Year = as.factor(rep(2014:2020, each = 6)),
  Region = rep(c("Lianyun", "Haizhou", "Ganyu", "Donghai", "Guanyun", "Guannan"), times = 7),
  Population = c(219.07, 219.07, 119.27, 121.95, 104.06, 81.44,
                 220.72, 220.72, 119.63, 122.84, 104.82, 82.17,
                 222.69, 222.69, 120.30, 123.45, 105.21, 82.64,
                 222.61, 222.61, 119.58, 123.91, 104.10, 81.91,
                 224.06, 224.06, 119.97, 124.62, 103.74, 81.92,
                 224.84, 224.84, 119.81, 124.55, 103.18, 81.84,
                 225.6, 225.6, 119.83, 124.63, 102.67, 81.50)
  )


# add Population density data (Unit: Number of People per Square Kilometer)
for (i in 1:length(data_cases_list)) {
  data_cases_list[[i]] <- data_cases_list[[i]] %>%
    left_join(population_data, by = c("Year", "region" = "Region")) %>%
    mutate(Population_Density = Population / if_else(region == "Lianyun", 1515.54,
                                                     if_else(region == "Haizhou", 1515.54,
                                                             if_else(region == "Ganyu", 1516.88,
                                                                     if_else(region == "Donghai", 2036.68,
                                                                             if_else(region == "Guanyun", 1528.54,
                                                                                     if_else(region == "Guannan", 1028.41, NA)))))))
  }



#### ---- Air Pollutant Exposure Concentrations ---- ####
# Calculate average pollutant concentrations over sliding windows of 0-1, 0-2, ..., 0-12 months (PM10, PM2.5)

library(dplyr)
library(lubridate)
library(slider)

# Assume your dataset is named pollutants_df and already contains columns for date, region, PM10, etc.
# pollutants_df <- read.csv("your_pollutants_df.csv") # Uncomment this line if your data is in a CSV file

# Convert the date column to Date type
pollutants_df$date <- as.Date(pollutants_df$date)

# Create a continuous date sequence from the minimum to the maximum date in the dataset
min_date <- min(pollutants_df$date)
max_date <- max(pollutants_df$date)
date_sequence <- seq(min_date, max_date, by = "day")

# Create a data frame containing all dates and regions
all_dates_regions <- expand_grid(date = date_sequence, region = unique(pollutants_df$region))

# Merge the original data with the continuous date data frame, filling missing dates with NA for pollutant concentrations
pollution_complete <- left_join(all_dates_regions, pollutants_df, by = c("date", "region"))

# Define a range of window sizes(1-52 week)
window_sizes <- seq(7, 364, by = 7)

# Initialize an empty list to store results
data_pollutants_list <- list()
# Use lapply to iterate over window sizes and calculate rolling average concentrations
data_pollutants_list <- lapply(window_sizes, function(window_size) {
  pollution_complete %>%
    group_by(region) %>%
    arrange(date) %>%
    mutate(
      RollingAvg_PM10 = slide_dbl(PM10, mean, .before = window_size - 1, .complete = TRUE),
      RollingAvg_PM2.5 = slide_dbl(PM2.5, mean, .before = window_size - 1, .complete = TRUE),
      # 5 meteorological factors
      RollingAvg_temp = slide_dbl(avg_temp, mean, .before = window_size - 1, .complete = TRUE),
      RollingAvg_pressure = slide_dbl(avg_pressure, mean, .before = window_size - 1, .complete = TRUE),
      RollingAvg_humidity = slide_dbl(avg_humidity, mean, .before = window_size - 1, .complete = TRUE),
      RollingAvg_windspeed = slide_dbl(avg_windspeed, mean, .before = window_size - 1, .complete = TRUE),
      RollingAvg_sunshine = slide_dbl(avg_sunshine, mean, .before = window_size - 1, .complete = TRUE)
      # Add more lines for additional pollutants if needed
      # RollingAvg_PMx = slide_dbl(PMx, mean, .before = window_size - 1, .complete = TRUE)
    ) %>%
    ungroup() # Ungroup for further processing
  })







########---- Lag 0 Weeks Exposure (Sliding Window Sizes [i=1,2,3,...,52]) ----########

# ---- Merge index cases with air pollutants (index_cases_list, data_pollutants_list with concurrent exposure)
result_list <- list()
for (i in 1:length(index_cases_list)) {
  result_list[[i]] <- left_join(index_cases_list[[i]], data_pollutants_list[[i]], by = c("date", "region"))
}


# ---- Merge Transmission Case Data with Index Cases & Air Pollutants
combined_df <- list()
for (i in 1:length(data_cases_list)) {
  combined_df[[i]] <- left_join(data_cases_list[[i]], result_list[[i]], by = c("date", "region"))
}






########---- GAM for PM10 ----########
# Load necessary libraries
library(dplyr)
library(mgcv)
# Set the number of decimal places for output results
digit <- 4 

# Initialize variables to store results
mod <- list()
coef <- NULL
OR <- NULL
LowCI <- NULL
UpperCI <- NULL
changeOR <- NULL
changeLow <- NULL
changeUpper <- NULL
se <- NULL
t.value <- NULL
Pvalue <- NULL

# Initialize result matrix and set column names
result <- matrix(NA, nrow=52, ncol=10)
colnames(result) <- c("coef", "OR", "LowCI", "UpperCI", "changeOR", "changeLow", "changeUpper", "se", "t.value", "Pvalue")

# Loop to build models and extract results

for(i in 1:52){
  mod[[i]] <- gam(transmission_rolling_cases ~ 
                    
                    RollingAvg_PM10 * index_rolling_cases + 
                    region +
                    Population_Density +
                    Urbanization_Level +
                    as.factor(Year) +
                    Season +
                    
                    s(Month, bs = 'cc') + 
                    s(RollingAvg_temp, bs='tp') +
                    s(RollingAvg_humidity, bs='tp') +
                    s(RollingAvg_sunshine, bs='tp') +
                    s(RollingAvg_windspeed, bs='tp'),
                  
                  data = combined_df[[i]],  
                  family = quasipoisson(link = "log"),
                  na.action = na.omit, # Omit missing values
                  method = "GCV.Cp")  
  
  # Extract coefficient, standard error, t-value, and p-value
  a <- summary(mod[[i]])$p.coeff[2]
  b <- summary(mod[[i]])$se[2]
  t <- round(summary(mod[[i]])$p.t[2], 3)
  e <- round(summary(mod[[i]])$p.pv[2], 5)
  
  # Calculate and extract odds ratio (OR) and its confidence interval
  c <- round(exp(10*coef(mod[[i]]))[2], digit)
  d <- as.data.frame(round(exp(10*confint.default(mod[[i]])), digit))
  Low <- d[2, 1]
  Upper <- d[2, 2]
  
  # Calculate percentage change in odds ratio
  f <- round((c - 1) * 100, digit)
  g <- round((Low - 1) * 100, digit)
  h <- round((Upper - 1) * 100, digit)
  
  # Fill the result matrix
  result[i,] <- c(a, c, Low, Upper, f, g, h, b, t, e)
}

# set Exposure Windows Size (unit: weeks)
Exposure_Window_Size <- seq(1, 52, by = 1)

# merging data
PM10_result <- cbind(Exposure_Window_Size,result)

# convert data to a data frame
PM10_data <- as.data.frame(PM10_result)

# View PM10_data
View(PM10_data)






########---- Plotting Residuals for PM10 ----########
# Load necessary libraries for plotting

library(ggplot2)
library(RColorBrewer)
library(readxl)

# Optionally check the structure of the PM10_data
str(PM10_data)

# Assuming the PM10_dataframe contains columns: Exposure_Window_Size, changeLow, changeUpper, changeOR, Pvalue
# Modify column names if necessary
# Set color palette

color_palette <- brewer.pal(4, "Dark2")
mycolor <- colorRampPalette(color_palette)(length(unique(PM10_data$Exposure_Window_Size)))  # Set number of colors based on unique Exposure_Window_Size values

# Convert Exposure_Window_Size to factor and set labels if needed
PM10_data$Exposure_Window_Size <- as.factor(PM10_data$Exposure_Window_Size)

# Add significance labels based on P-values
PM10_data$Significance <- ifelse(PM10_data$Pvalue < 0.001, "***",
                                 ifelse(PM10_data$Pvalue < 0.01, "**",
                                        ifelse(PM10_data$Pvalue < 0.05, "*", "")))


p1 <- ggplot(PM10_data, aes(x = Exposure_Window_Size, ymin = changeLow, ymax = changeUpper, y = changeOR, color = Exposure_Window_Size)) +
  geom_errorbar(width = 0.2, size = 1, position = position_dodge(width = 2)) +
  geom_point(size = 5, position = position_dodge(width = 1)) +
  
  # Add significance labels
  geom_text(aes(label = Significance, y = changeUpper + 0.05 * (changeUpper - changeLow)),
            vjust = -0.1, size = 6, color = "black") +
  
  scale_color_manual(values = mycolor) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 16),
    axis.title.x = element_text(size = 16),
    axis.text.y = element_text(size = 16),
    axis.title.y = element_text(size = 16),
    # Remove legend
    legend.position = "none",
    # Add border if needed
    panel.border = element_rect(colour = "black", fill = NA, size = 1),
    # Center title
    plot.title = element_text(hjust = 0.5, size = 20)
  ) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  # Add title with PM10 subscript
  labs(
    title = expression(paste("PM"[10], " ")),
    x = "Exposure window size (months)",
    y = expression(paste("Changes in PTB exogenous transmission risk (%) and 95% CI"))
  ) +
  # Add note on significance levels at the top left
  annotate("text", x = -Inf, y = Inf, label = "significant levels: * p <0.05, ** p <0.01, *** p <0.001",
           hjust = -0.05, vjust = 2, size = 5, color = "black")

# Display the plot
print(p1)









########---- GAM for PM2.5 ----########
# Load necessary libraries
library(dplyr)
library(mgcv)
# Set the number of decimal places for output results
digit <- 4 

# Initialize variables to store results
mod <- list()
coef <- NULL
OR <- NULL
LowCI <- NULL
UpperCI <- NULL
changeOR <- NULL
changeLow <- NULL
changeUpper <- NULL
se <- NULL
t.value <- NULL
Pvalue <- NULL

# Initialize result matrix and set column names
result <- matrix(NA, nrow=52, ncol=10)
colnames(result) <- c("coef", "OR", "LowCI", "UpperCI", "changeOR", "changeLow", "changeUpper", "se", "t.value", "Pvalue")

# Loop to build models and extract results

for(i in 1:52){
  mod[[i]] <- gam(transmission_rolling_cases ~ 
                    
                    RollingAvg_PM2.5 * index_rolling_cases + 
                    region +
                    Population_Density +
                    Urbanization_Level +
                    as.factor(Year) +
                    Season +
                    
                    s(Month, bs = 'cc') + 
                    s(RollingAvg_temp, bs='tp') +
                    s(RollingAvg_humidity, bs='tp') +
                    s(RollingAvg_sunshine, bs='tp') +
                    s(RollingAvg_windspeed, bs='tp'),
                  
                  data = combined_df[[i]],  
                  family = quasipoisson(link = "log"),
                  na.action = na.omit, # Omit missing values
                  method = "GCV.Cp")  
  
  # Extract coefficient, standard error, t-value, and p-value
  a <- summary(mod[[i]])$p.coeff[2]
  b <- summary(mod[[i]])$se[2]
  t <- round(summary(mod[[i]])$p.t[2], 3)
  e <- round(summary(mod[[i]])$p.pv[2], 5)
  
  # Calculate and extract odds ratio (OR) and its confidence interval
  c <- round(exp(10*coef(mod[[i]]))[2], digit)
  d <- as.data.frame(round(exp(10*confint.default(mod[[i]])), digit))
  Low <- d[2, 1]
  Upper <- d[2, 2]
  
  # Calculate percentage change in odds ratio
  f <- round((c - 1) * 100, digit)
  g <- round((Low - 1) * 100, digit)
  h <- round((Upper - 1) * 100, digit)
  
  # Fill the result matrix
  result[i,] <- c(a, c, Low, Upper, f, g, h, b, t, e)
}

# set Exposure Windows Size (unit: weeks)
Exposure_Window_Size <- seq(1, 52, by = 1)

# merging data
PM2.5_result <- cbind(Exposure_Window_Size,result)

# convert data to a data frame
PM2.5_data <- as.data.frame(PM2.5_result)

# View PM2.5_data
View(PM2.5_data)






########---- Plotting Residuals for PM2.5----########
# Load necessary libraries for plotting

library(ggplot2)
library(RColorBrewer)
library(readxl)

# Optionally check the structure of the PM2.5_data
str(PM2.5_data)

# Assuming the PM2.5_dataframe contains columns: Exposure_Window_Size, changeLow, changeUpper, changeOR, Pvalue
# Modify column names if necessary
# Set color palette

color_palette <- brewer.pal(4, "Dark2")
mycolor <- colorRampPalette(color_palette)(length(unique(PM2.5_data$Exposure_Window_Size)))  # Set number of colors based on unique Exposure_Window_Size values

# Convert Exposure_Window_Size to factor and set labels if needed
PM2.5_data$Exposure_Window_Size <- as.factor(PM2.5_data$Exposure_Window_Size)

# Add significance labels based on P-values
PM2.5_data$Significance <- ifelse(PM2.5_data$Pvalue < 0.001, "***",
                                 ifelse(PM2.5_data$Pvalue < 0.01, "**",
                                        ifelse(PM2.5_data$Pvalue < 0.05, "*", "")))


p2 <- ggplot(PM2.5_data, aes(x = Exposure_Window_Size, ymin = changeLow, ymax = changeUpper, y = changeOR, color = Exposure_Window_Size)) +
  geom_errorbar(width = 0.2, size = 1, position = position_dodge(width = 2)) +
  geom_point(size = 5, position = position_dodge(width = 1)) +
  
  # Add significance labels
  geom_text(aes(label = Significance, y = changeUpper + 0.05 * (changeUpper - changeLow)),
            vjust = -0.1, size = 6, color = "black") +
  
  scale_color_manual(values = mycolor) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 16),
    axis.title.x = element_text(size = 16),
    axis.text.y = element_text(size = 16),
    axis.title.y = element_text(size = 16),
    # Remove legend
    legend.position = "none",
    # Add border if needed
    panel.border = element_rect(colour = "black", fill = NA, size = 1),
    # Center title
    plot.title = element_text(hjust = 0.5, size = 20)
  ) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  # Add title with PM2.5 subscript
  labs(
    title = expression(paste("PM"[2.5], " ")),
    x = "Exposure window size (months)",
    y = expression(paste("Changes in PTB exogenous transmission risk (%) and 95% CI"))
  ) +
  # Add note on significance levels at the top left
  annotate("text", x = -Inf, y = Inf, label = "significant levels: * p <0.05, ** p <0.01, *** p <0.001",
           hjust = -0.05, vjust = 2, size = 5, color = "black")

# Display the plot
print(p2)










